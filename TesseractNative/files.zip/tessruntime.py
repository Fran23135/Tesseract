# =============================================================================
# tessruntime.py — Tesseract Compiler Frontend
# =============================================================================
# Hace exactamente lo que interpre.py hace al recorrer el JSON:
# construye tablas de símbolos, resuelve tipos, parsea expresiones,
# maneja scopes y funciones. PERO en lugar de ejecutar, produce
# representaciones estructuradas que tesscodegen.py convierte a LLVM IR.
# =============================================================================

from __future__ import annotations
import re
import ujson as json
from enum import Enum, auto
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional, Tuple, Union


# =============================================================================
# Sistema de Tipos de Tesseract
# =============================================================================

class TessType(Enum):
    """Tipos conocidos en tiempo de compilación."""
    INT     = "int"
    FLOAT   = "float"
    BOOL    = "bool"
    STRING  = "string"
    ARRAY   = "array"
    DICT    = "dict"
    NULL    = "null"
    DYNAMIC = "dynamic"   # tipo 'any' — se resuelve en runtime vía TessValue
    VOID    = "void"      # retorno de funciones sin return

    @staticmethod
    def from_str(s: str) -> "TessType":
        """Mapea los strings del AST a TessType."""
        mapping = {
            "int": TessType.INT, "float": TessType.FLOAT,
            "bool": TessType.BOOL, "string": TessType.STRING,
            "array": TessType.ARRAY, "dict": TessType.DICT,
            "null": TessType.NULL, "any": TessType.DYNAMIC,
            "dynamic": TessType.DYNAMIC, "void": TessType.VOID,
        }
        return mapping.get(s.lower(), TessType.DYNAMIC)

    def is_numeric(self) -> bool:
        return self in (TessType.INT, TessType.FLOAT)

    def is_static(self) -> bool:
        """True si el tipo es conocido en compilación (no DYNAMIC)."""
        return self not in (TessType.DYNAMIC,)


# =============================================================================
# Nodos de Expresión — reemplazo del eval()
# =============================================================================
# El ExpressionParser toma un string como "b*b-4*a*c" y produce un árbol
# de ExprNode. El codegen recorre ese árbol y emite instrucciones IR por nodo.

class ExprNode:
    """Nodo base del árbol de expresiones."""
    pass

@dataclass
class LiteralNode(ExprNode):
    value: Any          # int | float | bool | str
    ttype: TessType

@dataclass
class VarNode(ExprNode):
    name: str           # nombre de la variable o parámetro

@dataclass
class BinOpNode(ExprNode):
    op:    str          # '+' '-' '*' '/' '%' '==' '!=' '<' '>' '<=' '>='
    left:  ExprNode
    right: ExprNode

@dataclass
class UnaryNode(ExprNode):
    op:    str          # '!' '-'
    operand: ExprNode

@dataclass
class ConcatNode(ExprNode):
    """Concatenación con operador punto: "hola" . var . 2*3"""
    parts: List[ExprNode]

@dataclass
class FuncCallNode(ExprNode):
    name: str
    args: List[ExprNode]

@dataclass
class ModCallNode(ExprNode):
    module: str
    func:   str
    args:   List[ExprNode]

@dataclass
class ModVarNode(ExprNode):
    module: str
    var:    str

@dataclass
class ArrayAccessNode(ExprNode):
    array:   str
    indices: List[ExprNode]   # soporte a acceso profundo: arr[i:j]

@dataclass
class LogicalNode(ExprNode):
    op:    str          # '&&' '||'
    left:  ExprNode
    right: ExprNode


# =============================================================================
# Parser de Expresiones
# =============================================================================

class ExpressionParser:
    """
    Parsea strings de expresiones Tesseract en árboles ExprNode.
    Reemplaza el eval() de interpre.py con un árbol concreto
    que tesscodegen.py puede recorrer y emitir IR por cada nodo.
    """

    def parse(self, expr: str) -> ExprNode:
        expr = expr.strip()
        if not expr:
            return LiteralNode(None, TessType.NULL)
        return self._parse_logical(expr)

    # ── precedencia de operadores ────────────────────────────────────────────

    def _parse_logical(self, expr: str) -> ExprNode:
        """Nivel más bajo de precedencia: && ||"""
        # Dividir por || primero (menor precedencia)
        parts = self._split_by_op(expr, ['||', '&&'])
        if parts:
            op, left_str, right_str = parts
            op_mapped = '||' if op == '||' else '&&'
            return LogicalNode(op_mapped, self._parse_logical(left_str), self._parse_logical(right_str))
        return self._parse_comparison(expr)

    def _parse_comparison(self, expr: str) -> ExprNode:
        """Comparaciones: == != <= >= < >"""
        for op in ['==', '!=', '<=', '>=', '<', '>']:
            parts = self._split_by_op(expr, [op])
            if parts:
                _, left_str, right_str = parts
                return BinOpNode(op, self._parse_comparison(left_str), self._parse_concat(right_str))
        return self._parse_concat(expr)

    def _parse_concat(self, expr: str) -> ExprNode:
        """Concatenación con punto: solo cuando no es decimal."""
        # El punto es concatenación si no está entre dígitos
        parts = self._split_concat(expr)
        if len(parts) > 1:
            return ConcatNode([self._parse_additive(p) for p in parts])
        return self._parse_additive(expr)

    def _parse_additive(self, expr: str) -> ExprNode:
        """+ y -"""
        parts = self._split_by_op(expr, ['+', '-'])
        if parts:
            op, left_str, right_str = parts
            return BinOpNode(op, self._parse_additive(left_str), self._parse_multiplicative(right_str))
        return self._parse_multiplicative(expr)

    def _parse_multiplicative(self, expr: str) -> ExprNode:
        """* / %"""
        parts = self._split_by_op(expr, ['*', '/', '%'])
        if parts:
            op, left_str, right_str = parts
            return BinOpNode(op, self._parse_multiplicative(left_str), self._parse_unary(right_str))
        return self._parse_unary(expr)

    def _parse_unary(self, expr: str) -> ExprNode:
        """- unario y ! lógico"""
        expr = expr.strip()
        if expr.startswith('!'):
            return UnaryNode('!', self._parse_unary(expr[1:]))
        if expr.startswith('-') and len(expr) > 1 and not expr[1].isdigit():
            return UnaryNode('-', self._parse_unary(expr[1:]))
        return self._parse_primary(expr)

    def _parse_primary(self, expr: str) -> ExprNode:
        """Literales, variables, llamadas a función, acceso a arrays."""
        expr = expr.strip()

        # Paréntesis
        if expr.startswith('(') and expr.endswith(')') and self._balanced_parens(expr[1:-1]):
            return self.parse(expr[1:-1])

        # Booleanos
        if expr.lower() == 'true':
            return LiteralNode(True, TessType.BOOL)
        if expr.lower() == 'false':
            return LiteralNode(False, TessType.BOOL)

        # Null
        if expr.lower() == 'null':
            return LiteralNode(None, TessType.NULL)

        # String literal
        if (expr.startswith('"') and expr.endswith('"')) or \
           (expr.startswith("'") and expr.endswith("'")):
            return LiteralNode(expr[1:-1], TessType.STRING)

        # Número flotante
        try:
            return LiteralNode(float(expr), TessType.FLOAT) if '.' in expr else None
        except (ValueError, TypeError):
            pass

        # Número entero
        try:
            return LiteralNode(int(expr), TessType.INT)
        except ValueError:
            pass

        # Llamada mod.func(args) — antes que variable
        mod_call = re.match(r'^([A-Za-z_]\w*)\.([A-Za-z_]\w*)\s*\(([^)]*)\)$', expr)
        if mod_call:
            mod, func, raw_args = mod_call.groups()
            args = self._parse_arg_list(raw_args)
            return ModCallNode(mod, func, args)

        # Variable de módulo: mod.VAR
        mod_var = re.match(r'^([A-Za-z_]\w*)\.([A-Za-z_]\w*)$', expr)
        if mod_var:
            mod, var = mod_var.groups()
            return ModVarNode(mod, var)

        # Llamada a función: func(args)
        func_call = re.match(r'^([A-Za-z_]\w*)\s*\(([^)]*)\)$', expr)
        if func_call:
            name, raw_args = func_call.groups()
            args = self._parse_arg_list(raw_args)
            return FuncCallNode(name, args)

        # Acceso a array: arr[idx] o arr[i:j]
        arr_access = re.match(r'^([A-Za-z_]\w*)\[(.+)\]$', expr)
        if arr_access:
            name, raw_idx = arr_access.groups()
            indices = [self.parse(i.strip()) for i in raw_idx.split(':')]
            return ArrayAccessNode(name, indices)

        # Identificador / variable
        if re.match(r'^[A-Za-z_]\w*$', expr):
            return VarNode(expr)

        # Fallback — retornar como string dinámico (será resuelto por runtime)
        return LiteralNode(expr, TessType.DYNAMIC)

    # ── helpers ──────────────────────────────────────────────────────────────

    def _split_by_op(self, expr: str, ops: List[str]) -> Optional[Tuple[str, str, str]]:
        """
        Encuentra la última ocurrencia de un operador en expr respetando
        paréntesis, y retorna (op, izquierda, derecha). Recorre de derecha
        a izquierda para asegurar asociatividad izquierda.
        """
        depth = 0
        # Recorrer de derecha a izquierda
        i = len(expr) - 1
        while i >= 0:
            c = expr[i]
            if c in ')]}': depth += 1
            elif c in '([{': depth -= 1
            if depth == 0:
                for op in ops:
                    end = i + 1
                    start = i - len(op) + 1
                    if start >= 0 and expr[start:end] == op:
                        left  = expr[:start].strip()
                        right = expr[end:].strip()
                        if left and right:
                            return op, left, right
            i -= 1
        return None

    def _split_concat(self, expr: str) -> List[str]:
        """
        Divide una expresión por el operador punto de concatenación,
        ignorando decimales (3.14) y llamadas de módulo (math.sqrt).
        """
        parts = []
        current = []
        depth = 0
        i = 0
        while i < len(expr):
            c = expr[i]
            if c in '([{': depth += 1
            elif c in ')]}': depth -= 1
            if c == '.' and depth == 0:
                # Verificar que no es decimal ni acceso a módulo
                prev = expr[i-1] if i > 0 else ''
                nxt  = expr[i+1] if i+1 < len(expr) else ''
                if prev.isdigit() and nxt.isdigit():
                    current.append(c); i += 1; continue
                # Es operador de concatenación
                parts.append(''.join(current).strip())
                current = []
                i += 1
                continue
            current.append(c)
            i += 1
        parts.append(''.join(current).strip())
        return [p for p in parts if p]

    def _balanced_parens(self, s: str) -> bool:
        depth = 0
        for c in s:
            if c == '(': depth += 1
            elif c == ')': depth -= 1
            if depth < 0: return False
        return depth == 0

    def _parse_arg_list(self, raw: str) -> List[ExprNode]:
        """Parsea lista de argumentos separados por coma."""
        if not raw.strip():
            return []
        args = []
        for part in raw.split(','):
            part = part.strip()
            # Quitar "nombre: valor" → solo el valor
            if ':' in part and not (part.startswith('"') or part.startswith("'")):
                _, val = part.split(':', 1)
                part = val.strip()
            args.append(self.parse(part))
        return args


# =============================================================================
# Símbolo de Compilación
# =============================================================================

@dataclass
class TessSymbol:
    """
    Representa un símbolo en la tabla de compilación.
    ir_ref: referencia al alloca o valor LLVM (lo llena tesscodegen.py).
    """
    name:          str
    ttype:         TessType
    is_const:      bool        = False
    const_value:   Any         = None   # valor conocido en compilación, si existe
    ir_ref:        Any         = None   # llvmlite AllocaInstr o Value


@dataclass
class TessFunction:
    """Definición de función Tesseract con toda la información necesaria para codegen."""
    name:        str
    params:      Dict[str, TessType]   # nombre → tipo
    return_type: TessType
    body:        List[dict]             # nodos del bloque (JSON crudo)
    ir_func:     Any = None            # llvmlite Function (lo llena codegen)


@dataclass
class TessModule:
    """Módulo cargado (nativo o fuente)."""
    name:      str
    is_source: bool        # True = .tss, False = nativo
    path:      str = ""


# =============================================================================
# Tabla de Símbolos de Compilación
# =============================================================================

class CompileSymbolTable:
    """
    Misma arquitectura de scopes apilados que SymbolTable en interpre.py.
    La diferencia: almacena TessSymbol en lugar de Symbol, y no ejecuta.
    """

    def __init__(self):
        self._scopes:    List[Dict[str, TessSymbol]]  = [{}]  # [0] = global
        self._functions: Dict[str, TessFunction]       = {}
        self._modules:   Dict[str, TessModule]         = {}

    # ── scopes ───────────────────────────────────────────────────────────────

    def push_scope(self):
        self._scopes.append({})

    def pop_scope(self):
        if len(self._scopes) > 1:
            self._scopes.pop()

    @property
    def current_scope(self) -> Dict[str, TessSymbol]:
        return self._scopes[-1]

    # ── variables ────────────────────────────────────────────────────────────

    def declare(self, sym: TessSymbol):
        self._scopes[-1][sym.name] = sym

    def lookup(self, name: str) -> Optional[TessSymbol]:
        for scope in reversed(self._scopes):
            if name in scope:
                return scope[name]
        return None

    def update_ir_ref(self, name: str, ir_ref: Any):
        """Guarda la referencia LLVM en el símbolo ya declarado."""
        sym = self.lookup(name)
        if sym:
            sym.ir_ref = ir_ref

    # ── funciones ────────────────────────────────────────────────────────────

    def declare_function(self, fn: TessFunction):
        self._functions[fn.name] = fn

    def lookup_function(self, name: str) -> Optional[TessFunction]:
        return self._functions.get(name)

    # ── módulos ──────────────────────────────────────────────────────────────

    def register_module(self, mod: TessModule):
        self._modules[mod.name] = mod

    def is_module_loaded(self, name: str) -> bool:
        return name in self._modules

    def get_module(self, name: str) -> Optional[TessModule]:
        return self._modules.get(name)

    # ── utilidades ───────────────────────────────────────────────────────────

    def all_globals(self) -> Dict[str, TessSymbol]:
        return dict(self._scopes[0])

    def all_functions(self) -> Dict[str, TessFunction]:
        return dict(self._functions)

    def all_modules(self) -> Dict[str, TessModule]:
        return dict(self._modules)


# =============================================================================
# Inferencia de Tipo
# =============================================================================

class TypeInferrer:
    """
    Infiere TessType a partir de valores Python o de nodos del AST.
    Misma lógica que _infer_type e _get_type_name en interpre.py.
    """

    @staticmethod
    def from_python_value(value: Any) -> TessType:
        if value is None:
            return TessType.NULL
        if isinstance(value, bool):
            return TessType.BOOL
        if isinstance(value, int):
            return TessType.INT
        if isinstance(value, float):
            return TessType.FLOAT
        if isinstance(value, str):
            return TessType.STRING
        if isinstance(value, list):
            return TessType.ARRAY
        if isinstance(value, dict):
            return TessType.DICT
        return TessType.DYNAMIC

    @staticmethod
    def from_ast_node(value_node: dict) -> TessType:
        """
        Lee el nodo value del AST (como lo hace handle_VariableDeclaration)
        y determina el tipo.
        """
        explicit = value_node.get("explicitType")
        if explicit:
            return TessType.from_str(explicit)

        ast_type = value_node.get("type", "")
        raw      = value_node.get("value")

        if ast_type == "NULL":
            return TessType.NULL
        if ast_type == "string":
            return TessType.STRING
        if ast_type in ("ModuleVariable", "function"):
            return TessType.DYNAMIC  # resultado depende del módulo

        # Inferir desde el valor crudo
        if isinstance(raw, bool):
            return TessType.BOOL
        if isinstance(raw, int):
            return TessType.INT
        if isinstance(raw, float):
            return TessType.FLOAT
        if isinstance(raw, list):
            return TessType.ARRAY
        if isinstance(raw, dict):
            return TessType.DICT
        if isinstance(raw, str):
            if raw.lower() == "true" or raw.lower() == "false":
                return TessType.BOOL
            if raw.lower() == "null":
                return TessType.NULL
            try:
                int(raw)
                return TessType.INT
            except ValueError:
                pass
            try:
                float(raw)
                return TessType.FLOAT
            except ValueError:
                pass
            # Si tiene operadores aritméticos, probablemente resultado numérico
            # pero no podemos saber sin evaluar — DYNAMIC
            if any(op in raw for op in ['+', '-', '*', '/', '%']):
                return TessType.DYNAMIC

        return TessType.DYNAMIC

    @staticmethod
    def from_expr_node(node: ExprNode) -> TessType:
        """Infiere el tipo de un nodo de expresión ya parseado."""
        if isinstance(node, LiteralNode):
            return node.ttype
        if isinstance(node, BinOpNode):
            if node.op in ('==', '!=', '<', '>', '<=', '>='):
                return TessType.BOOL
            left  = TypeInferrer.from_expr_node(node.left)
            right = TypeInferrer.from_expr_node(node.right)
            if left == TessType.FLOAT or right == TessType.FLOAT:
                return TessType.FLOAT
            if left == TessType.INT and right == TessType.INT:
                return TessType.INT
            return TessType.DYNAMIC
        if isinstance(node, LogicalNode):
            return TessType.BOOL
        if isinstance(node, ConcatNode):
            return TessType.STRING
        if isinstance(node, (FuncCallNode, ModCallNode, ArrayAccessNode)):
            return TessType.DYNAMIC
        if isinstance(node, VarNode):
            return TessType.DYNAMIC  # se resolverá al buscar en la tabla
        return TessType.DYNAMIC


# =============================================================================
# Contexto de Compilación — el corazón del frontend
# =============================================================================

class CompileContext:
    """
    Recorre el JSON AST igual que Interpreter en interpre.py.
    En lugar de ejecutar cada nodo, lo analiza y puebla:
      - symbol_table: tabla de compilación con tipos y refs IR
      - expr_parser:  parser de expresiones
    
    tesscodegen.py recibe este contexto y emite IR usando sus datos.
    """

    def __init__(self, debug: bool = False):
        self.symbol_table  = CompileSymbolTable()
        self.expr_parser   = ExpressionParser()
        self.type_inferrer = TypeInferrer()
        self.debug         = debug
        self._current_func: Optional[str] = None

    # ── log ──────────────────────────────────────────────────────────────────

    def _log(self, msg: str):
        if self.debug:
            print(f"[CompileCtx] {msg}")

    # ── punto de entrada ─────────────────────────────────────────────────────

    def analyze(self, ast: dict):
        """
        Primera pasada: recorre el AST y construye todas las tablas.
        Equivale al interpret() de interpre.py pero sin ejecutar.
        """
        if "Program" not in ast:
            raise ValueError("El AST debe tener un nodo raíz 'Program'.")

        program_nodes = ast["Program"]
        i = 0
        while i < len(program_nodes):
            node = program_nodes[i]
            node_type = list(node.keys())[0]

            # WhileLoop: en interpre.py puede tener su bloque como nodo siguiente
            if node_type == "WhileLoop":
                if i + 1 < len(program_nodes) and "Block" in program_nodes[i + 1]:
                    node["WhileLoop"]["block"] = program_nodes[i + 1]["Block"]
                    i += 2
                    self.analyze_node(node)
                    continue

            # SwitchStatement: igual
            if node_type == "SwitchStatement":
                if i + 1 < len(program_nodes) and "block" in program_nodes[i + 1]:
                    node["SwitchStatement"]["cases"] = program_nodes[i + 1].get("cases", [])
                    i += 2
                    self.analyze_node(node)
                    continue

            self.analyze_node(node)
            i += 1

    def analyze_node(self, node: dict):
        """
        Despacha al analizador correcto según el tipo de nodo.
        Mismo patrón que execute_node en interpre.py.
        """
        if not node:
            return
        node_type = list(node.keys())[0]
        self._log(f"analyze_node: {node_type}")
        handler = getattr(self, f"_analyze_{node_type}", self._analyze_unknown)
        handler(node[node_type])

    def analyze_block(self, block: List[dict]):
        """Analiza una lista de nodos (bloque)."""
        for stmt in block:
            self.analyze_node(stmt)

    # ── analizadores por nodo — misma cobertura que interpre.py ──────────────

    def _analyze_VariableDeclaration(self, node: dict):
        """
        Mismo recorrido que handle_VariableDeclaration en interpre.py.
        Extrae nombre, tipo y valor; registra en la tabla.
        """
        name       = node["name"]
        value_node = node.get("value", {})
        ttype      = self.type_inferrer.from_ast_node(value_node)
        raw        = value_node.get("value")
        is_const   = False

        # Valor constante conocido en compilación
        const_val = None
        if ttype in (TessType.INT, TessType.FLOAT, TessType.BOOL, TessType.STRING):
            if isinstance(raw, (int, float, bool)):
                const_val = raw
            elif isinstance(raw, str) and not any(op in raw for op in ['+', '-', '*', '/', '%']):
                if raw.lower() not in ('true', 'false', 'null'):
                    const_val = raw

        sym = TessSymbol(name=name, ttype=ttype, is_const=is_const, const_value=const_val)
        self.symbol_table.declare(sym)
        self._log(f"Declarada variable '{name}' tipo={ttype.value} const_val={const_val}")

    def _analyze_VariableAsignement(self, node: dict):
        """
        Detecta reasignación. Si el símbolo ya existe, verifica que no sea const.
        No modifica el tipo — en Tesseract las variables son dinámicas por default.
        """
        name = node["name"]
        sym  = self.symbol_table.lookup(name)
        if sym is None:
            # Declaración implícita (algunos ASTs pueden omitir VariableDeclaration)
            value_node = node.get("value", {})
            ttype = self.type_inferrer.from_ast_node(value_node)
            sym = TessSymbol(name=name, ttype=ttype)
            self.symbol_table.declare(sym)
            self._log(f"Reasignación implícita: '{name}' tipo={ttype.value}")
        else:
            self._log(f"Reasignación: '{name}' (tipo actual={sym.ttype.value})")

    def _analyze_ConstantDeclaration(self, node: dict):
        """Constantes — misma lógica que handle_ConstantDeclaration."""
        name       = node["name"]
        value_node = node.get("value", {})
        ttype      = self.type_inferrer.from_ast_node(value_node)
        raw        = value_node.get("value")
        const_val  = raw if isinstance(raw, (int, float, bool, str)) else None
        sym = TessSymbol(name=name, ttype=ttype, is_const=True, const_value=const_val)
        self.symbol_table.declare(sym)
        self._log(f"Declarada constante '{name}' tipo={ttype.value}")

    def _analyze_Function(self, node: dict):
        """
        Mismo recorrido que handle_Function + _parse_function_parameters.
        Registra la función con sus parámetros tipados y el bloque crudo.
        """
        name   = node["name"]
        params = self._parse_function_params(node.get("parameters", {}))
        ret    = TessType.from_str(node.get("explicitType", "dynamic"))
        body   = node.get("block", [])

        fn = TessFunction(name=name, params=params, return_type=ret, body=body)
        self.symbol_table.declare_function(fn)
        self._log(f"Declarada función '{name}' params={params} ret={ret.value}")

        # Analizar el cuerpo de la función para registrar sus símbolos locales
        old_func = self._current_func
        self._current_func = name
        self.symbol_table.push_scope()
        # Declarar parámetros en el scope de la función
        for pname, ptype in params.items():
            psym = TessSymbol(name=pname, ttype=ptype)
            self.symbol_table.declare(psym)
        self.analyze_block(body)
        self.symbol_table.pop_scope()
        self._current_func = old_func

    def _analyze_FunctionCall(self, node: dict):
        """Llamada a función — solo validación, no ejecución."""
        fname = node["function"]
        self._log(f"Llamada a función: '{fname}'")

    def _analyze_CallExpression(self, node: dict):
        """Llamada a función builtin (print, read, Return, Break, etc.)"""
        fname = node.get("function", "")
        self._log(f"CallExpression: '{fname}'")

    def _analyze_LibraryCall(self, node: dict):
        """
        Mismo recorrido que handle_LibraryCall.
        Registra el módulo (nativo o .tss) en la tabla.
        """
        module_raw = node["module"]
        alias      = node.get("alias")
        is_source  = module_raw.strip('"\'').lower().endswith('.tss')
        name       = alias if alias else module_raw.strip('"\'')
        if is_source:
            # Para .tss el nombre del módulo se deriva del archivo
            import os
            name = alias if alias else os.path.splitext(os.path.basename(name))[0]
        mod = TessModule(name=name, is_source=is_source, path=module_raw)
        self.symbol_table.register_module(mod)
        self._log(f"Módulo registrado: '{name}' source={is_source}")

    def _analyze_if_Condition(self, node: dict):
        """Analiza los bloques del if/elseif/else."""
        self.symbol_table.push_scope()
        self.analyze_block(node.get("block", []))
        self.symbol_table.pop_scope()

        if "elseIf" in node:
            self._analyze_elseif_chain(node["elseIf"])

        if "else" in node:
            self.symbol_table.push_scope()
            self.analyze_block(node["else"].get("block", []))
            self.symbol_table.pop_scope()

    def _analyze_elseif_chain(self, node: dict):
        self.symbol_table.push_scope()
        self.analyze_block(node.get("block", []))
        self.symbol_table.pop_scope()
        if "elseIf" in node:
            self._analyze_elseif_chain(node["elseIf"])

    def _analyze_ForLoop(self, node: dict):
        """
        Mismo recorrido que handle_ForLoop.
        Registra la variable iteradora.
        """
        var_name = node["variable"]
        sym = TessSymbol(name=var_name, ttype=TessType.INT)
        self.symbol_table.push_scope()
        self.symbol_table.declare(sym)
        self.analyze_block(node.get("block", []))
        self.symbol_table.pop_scope()
        self._log(f"ForLoop: iterador '{var_name}'")

    def _analyze_WhileLoop(self, node: dict):
        self.symbol_table.push_scope()
        self.analyze_block(node.get("block", []))
        self.symbol_table.pop_scope()

    def _analyze_PerformWhileLoop(self, node: dict):
        """do-while de Tesseract."""
        self.symbol_table.push_scope()
        self.analyze_block(node.get("block", []))
        self.symbol_table.pop_scope()

    def _analyze_SwitchStatement(self, node: dict):
        for case in node.get("cases", []):
            self.symbol_table.push_scope()
            self.analyze_block(case.get("block", []))
            self.symbol_table.pop_scope()
        default = node.get("defaultCase")
        if default:
            self.symbol_table.push_scope()
            self.analyze_block(default.get("block", []))
            self.symbol_table.pop_scope()

    def _analyze_PostIncrementStatement(self, node: dict):
        pass  # solo modifica variable existente

    def _analyze_PostDecrementStatement(self, node: dict):
        pass

    def _analyze_PreIncrementStatement(self, node: dict):
        pass

    def _analyze_PreDecrementStatement(self, node: dict):
        pass

    def _analyze_ParameterAsignement(self, node: dict):
        pass  # ya declarado al analizar la función

    def _analyze_unknown(self, node_content):
        self._log(f"ADVERTENCIA: Nodo desconocido: {node_content}")

    # ── helpers ──────────────────────────────────────────────────────────────

    def _parse_function_params(self, params_node: dict) -> Dict[str, TessType]:
        """
        Misma lógica que _parse_function_parameters en interpre.py.
        Retorna {nombre: TessType}.
        """
        result = {}
        if "value" in params_node:
            for part in params_node["value"].split(','):
                part = part.strip()
                if not part:
                    continue
                if ':' in part:
                    pname, ptype = part.split(':', 1)
                    result[pname.strip()] = TessType.from_str(ptype.strip())
                else:
                    result[part] = TessType.DYNAMIC
        return result

    # ── API pública para tesscodegen.py ──────────────────────────────────────

    def parse_expression(self, expr_str: str) -> ExprNode:
        """
        Parsea una expresión string → árbol ExprNode.
        tesscodegen.py llama esto cuando necesita emitir IR para una expresión.
        """
        return self.expr_parser.parse(expr_str)

    def resolve_var_type(self, name: str) -> TessType:
        """Retorna el tipo de una variable según la tabla de símbolos."""
        sym = self.symbol_table.lookup(name)
        return sym.ttype if sym else TessType.DYNAMIC

    def get_function(self, name: str) -> Optional[TessFunction]:
        return self.symbol_table.lookup_function(name)

    def get_all_functions(self) -> Dict[str, TessFunction]:
        return self.symbol_table.all_functions()

    def get_all_globals(self) -> Dict[str, TessSymbol]:
        return self.symbol_table.all_globals()

    def is_module_loaded(self, name: str) -> bool:
        return self.symbol_table.is_module_loaded(name)


# =============================================================================
# Función de entrada: analizar un JSON AST y retornar el contexto listo
# =============================================================================

def analyze_ast(ast_json: dict, debug: bool = False) -> CompileContext:
    """
    Punto de entrada principal.
    Lee el JSON AST, construye todas las tablas, retorna el CompileContext
    listo para que tesscodegen.py emita LLVM IR.
    """
    ctx = CompileContext(debug=debug)
    ctx.analyze(ast_json)
    return ctx


def analyze_ast_file(path: str, debug: bool = False) -> CompileContext:
    """Versión que lee directamente desde un archivo JSON."""
    with open(path, 'r', encoding='utf-8') as f:
        ast_data = json.load(f)
    return analyze_ast(ast_data, debug=debug)


# =============================================================================
# CLI básico para pruebas
# =============================================================================

if __name__ == "__main__":
    import sys
    if len(sys.argv) < 2:
        print("Uso: python tessruntime.py <ast.json> [-d]")
        sys.exit(1)

    debug_flag = '-d' in sys.argv
    ctx = analyze_ast_file(sys.argv[1], debug=debug_flag)

    print("\n=== TABLA DE SÍMBOLOS GLOBALES ===")
    for name, sym in ctx.get_all_globals().items():
        print(f"  {name}: {sym.ttype.value}"
              + (f" = {sym.const_value}" if sym.const_value is not None else "")
              + (" [const]" if sym.is_const else ""))

    print("\n=== FUNCIONES ===")
    for name, fn in ctx.get_all_functions().items():
        params_str = ", ".join(f"{p}:{t.value}" for p, t in fn.params.items())
        print(f"  {name}({params_str}) -> {fn.return_type.value}")

    print("\n=== MÓDULOS ===")
    for name, mod in ctx.symbol_table.all_modules().items():
        kind = "fuente (.tss)" if mod.is_source else "nativo"
        print(f"  {name} [{kind}]")
