# =============================================================================
# tesscodegen.py — Tesseract LLVM IR Code Generator
# =============================================================================
# Recorre el JSON AST usando el CompileContext de tessruntime.py.
# Por cada nodo emite instrucciones LLVM IR via llvmlite.
#
# Manejo de tipos:
#   - Tipos estáticos conocidos (int, float, bool, string) → tipos LLVM nativos
#   - Tipo dinámico (any / dynamic) → struct TessValue del runtime C
#
# Runtime C (tess_runtime.c / tess_runtime.h) provee:
#   - TessValue: tagged union para valores dinámicos
#   - tess_print, tess_read, tess_concat
#   - tess_array_*, tess_dict_*
#   - tess_op_add, tess_op_sub, etc. para operaciones dinámicas
# =============================================================================

from __future__ import annotations
import os
import sys
import ujson as json
from typing import Any, Dict, List, Optional, Tuple

try:
    import llvmlite.ir as ir
    import llvmlite.binding as llvm
except ImportError:
    print("ERROR: llvmlite no está instalado. Ejecuta: pip install llvmlite")
    sys.exit(1)

from tessruntime import (
    CompileContext, TessType, TessSymbol, TessFunction,
    ExprNode, LiteralNode, VarNode, BinOpNode, UnaryNode,
    ConcatNode, FuncCallNode, ModCallNode, ModVarNode,
    ArrayAccessNode, LogicalNode, analyze_ast, analyze_ast_file
)


# =============================================================================
# Sistema de Tipos LLVM
# =============================================================================

class LLVMTypes:
    """
    Mapea TessType a tipos LLVM IR.
    El tipo dinámico usa un puntero a TessValue (struct del runtime C).
    """

    def __init__(self, module: ir.Module):
        self.module = module
        self._init_tess_value(module)

    def _init_tess_value(self, module: ir.Module):
        """
        Define el struct TessValue en IR.
        Equivale a:
          struct TessValue {
              i32 tag;         // 0=null 1=int 2=float 3=bool 4=string 5=array 6=dict
              i64 data;        // interpretado según tag (int/float/ptr)
          };
        Usamos i64 para el campo data — suficiente para int64, double y punteros.
        """
        self.tess_value_t = module.context.get_identified_type("TessValue")
        if not self.tess_value_t.elements:
            self.tess_value_t.set_body(
                ir.IntType(32),   # tag
                ir.IntType(64),   # data (int/float bits/ptr)
            )
        self.tess_value_ptr_t = self.tess_value_t.as_pointer()

    # ── mapeo de tipos ───────────────────────────────────────────────────────

    def llvm_type(self, ttype: TessType) -> ir.Type:
        mapping = {
            TessType.INT:     ir.IntType(64),
            TessType.FLOAT:   ir.DoubleType(),
            TessType.BOOL:    ir.IntType(1),
            TessType.STRING:  ir.IntType(8).as_pointer(),   # char*
            TessType.NULL:    ir.IntType(64),
            TessType.VOID:    ir.VoidType(),
            TessType.DYNAMIC: self.tess_value_ptr_t,
            TessType.ARRAY:   self.tess_value_ptr_t,
            TessType.DICT:    self.tess_value_ptr_t,
        }
        return mapping.get(ttype, self.tess_value_ptr_t)

    def is_dynamic(self, ttype: TessType) -> bool:
        return ttype in (TessType.DYNAMIC, TessType.ARRAY, TessType.DICT)

    # ── constantes de tag para TessValue ────────────────────────────────────
    TAG_NULL   = ir.Constant(ir.IntType(32), 0)
    TAG_INT    = ir.Constant(ir.IntType(32), 1)
    TAG_FLOAT  = ir.Constant(ir.IntType(32), 2)
    TAG_BOOL   = ir.Constant(ir.IntType(32), 3)
    TAG_STRING = ir.Constant(ir.IntType(32), 4)
    TAG_ARRAY  = ir.Constant(ir.IntType(32), 5)
    TAG_DICT   = ir.Constant(ir.IntType(32), 6)


# =============================================================================
# Declaraciones del Runtime C
# =============================================================================

class RuntimeAPI:
    """
    Declara en el módulo IR todas las funciones del runtime C (tess_runtime.c).
    tesscodegen.py las llama con `builder.call(fn, args)` cuando necesita
    manejar operaciones dinámicas.
    """

    def __init__(self, module: ir.Module, types: LLVMTypes):
        self.module = module
        self.types  = types
        self.funcs: Dict[str, ir.Function] = {}
        self._declare_all()

    def _decl(self, name: str, ret: ir.Type, *args: ir.Type) -> ir.Function:
        fn_type = ir.FunctionType(ret, list(args))
        fn = ir.Function(self.module, fn_type, name=name)
        self.funcs[name] = fn
        return fn

    def _declare_all(self):
        tv  = self.types.tess_value_ptr_t
        i64 = ir.IntType(64)
        i32 = ir.IntType(32)
        i8p = ir.IntType(8).as_pointer()
        dbl = ir.DoubleType()
        i1  = ir.IntType(1)
        void= ir.VoidType()

        # ── I/O ──────────────────────────────────────────────────────────────
        self._decl("tess_print_int",    void, i64)
        self._decl("tess_print_float",  void, dbl)
        self._decl("tess_print_bool",   void, i1)
        self._decl("tess_print_string", void, i8p)
        self._decl("tess_print_value",  void, tv)    # dinámico
        self._decl("tess_print_null",   void)

        self._decl("tess_read_string",  i8p)
        self._decl("tess_read_int",     i64)
        self._decl("tess_read_float",   dbl)

        # ── Construcción de TessValue ─────────────────────────────────────────
        self._decl("tess_make_int",    tv, i64)
        self._decl("tess_make_float",  tv, dbl)
        self._decl("tess_make_bool",   tv, i1)
        self._decl("tess_make_string", tv, i8p)
        self._decl("tess_make_null",   tv)

        # ── Operaciones dinámicas (TessValue op TessValue) ───────────────────
        self._decl("tess_add",   tv, tv, tv)
        self._decl("tess_sub",   tv, tv, tv)
        self._decl("tess_mul",   tv, tv, tv)
        self._decl("tess_div",   tv, tv, tv)
        self._decl("tess_mod",   tv, tv, tv)
        self._decl("tess_eq",    tv, tv, tv)
        self._decl("tess_neq",   tv, tv, tv)
        self._decl("tess_lt",    tv, tv, tv)
        self._decl("tess_gt",    tv, tv, tv)
        self._decl("tess_lte",   tv, tv, tv)
        self._decl("tess_gte",   tv, tv, tv)
        self._decl("tess_and",   tv, tv, tv)
        self._decl("tess_or",    tv, tv, tv)
        self._decl("tess_not",   tv, tv)
        self._decl("tess_neg",   tv, tv)
        self._decl("tess_concat",tv, tv, tv)   # concatenación con punto

        # ── Arrays ───────────────────────────────────────────────────────────
        self._decl("tess_array_new",    tv)
        self._decl("tess_array_push",   void, tv, tv)
        self._decl("tess_array_get",    tv, tv, i64)
        self._decl("tess_array_set",    void, tv, i64, tv)
        self._decl("tess_array_len",    i64, tv)

        # ── Diccionarios ─────────────────────────────────────────────────────
        self._decl("tess_dict_new",     tv)
        self._decl("tess_dict_get",     tv, tv, i8p)
        self._decl("tess_dict_set",     void, tv, i8p, tv)
        self._decl("tess_dict_has",     i1, tv, i8p)

        # ── Conversiones ─────────────────────────────────────────────────────
        self._decl("tess_to_int",       i64, tv)
        self._decl("tess_to_float",     dbl, tv)
        self._decl("tess_to_bool",      i1,  tv)
        self._decl("tess_to_string",    i8p, tv)
        self._decl("tess_value_truthy", i1,  tv)   # para condiciones dinámicas

        # ── Incremento/decremento dinámico ───────────────────────────────────
        self._decl("tess_inc", tv, tv)
        self._decl("tess_dec", tv, tv)

    def get(self, name: str) -> ir.Function:
        if name not in self.funcs:
            raise KeyError(f"Función de runtime '{name}' no declarada")
        return self.funcs[name]


# =============================================================================
# Generador de IR
# =============================================================================

class CodeGen:
    """
    Recorre el JSON AST (con ayuda del CompileContext de tessruntime)
    y emite LLVM IR para cada nodo.

    Estructura de datos internas durante la emisión:
      _ir_vars   : {nombre -> AllocaInstr}  — variables del scope actual
      _ir_funcs  : {nombre -> ir.Function}  — funciones Tesseract en IR
      _scope_stack: [dict] — stack de scopes de vars IR
    """

    def __init__(self, ctx: CompileContext, module_name: str = "tesseract_module"):
        self.ctx       = ctx
        self.module    = ir.Module(name=module_name)
        self.module.triple = llvm.get_default_triple()

        self.types     = LLVMTypes(self.module)
        self.runtime   = RuntimeAPI(self.module, self.types)

        self._scope_stack: List[Dict[str, Any]] = [{}]   # [0] = global
        self._ir_funcs:    Dict[str, ir.Function] = {}
        self._builder:     Optional[ir.IRBuilder]  = None
        self._current_func_name: Optional[str]     = None

        # Bloques de control de flujo
        self._break_target:  Optional[ir.Block] = None
        self._return_alloca: Optional[Any]       = None
        self._return_block:  Optional[ir.Block]  = None

    # ── scopes de IR ─────────────────────────────────────────────────────────

    def _push_scope(self):
        self._scope_stack.append({})

    def _pop_scope(self):
        if len(self._scope_stack) > 1:
            self._scope_stack.pop()

    def _declare_ir_var(self, name: str, alloca: Any):
        self._scope_stack[-1][name] = alloca

    def _lookup_ir_var(self, name: str) -> Optional[Any]:
        for scope in reversed(self._scope_stack):
            if name in scope:
                return scope[name]
        return None

    # ── helpers de builder ───────────────────────────────────────────────────

    def _alloca(self, name: str, llvm_type: ir.Type) -> Any:
        """Crea un alloca en el bloque de entrada de la función actual."""
        # Los allocas van siempre en el entry block para que el optimizador
        # pueda convertirlos a registros (mem2reg pass)
        fn = self._builder.function
        entry_block = fn.entry_basic_block
        tmp_builder = ir.IRBuilder(entry_block)
        # Insertar al inicio del entry block
        tmp_builder.position_at_start(entry_block)
        return tmp_builder.alloca(llvm_type, name=name)

    def _str_const(self, s: str) -> Any:
        """Crea una constante string global y retorna un i8* a ella."""
        encoded = (s + '\0').encode('utf-8')
        str_type = ir.ArrayType(ir.IntType(8), len(encoded))
        gvar = ir.GlobalVariable(self.module, str_type, name=f".str.{abs(hash(s))}")
        gvar.global_constant = True
        gvar.initializer = ir.Constant(str_type, bytearray(encoded))
        zero = ir.Constant(ir.IntType(32), 0)
        return self._builder.gep(gvar, [zero, zero], inbounds=True, name="str")

    # ── punto de entrada ─────────────────────────────────────────────────────

    def generate(self, ast: dict) -> str:
        """
        Genera el LLVM IR completo para el AST.
        Retorna el IR como string.
        """
        program_nodes = ast.get("Program", [])

        # Paso 1: Pre-declarar todas las funciones (forward declarations)
        # para permitir llamadas antes de la definición (como interpre.py
        # que registra todas las funciones en la tabla antes de ejecutar)
        self._predeclare_functions(program_nodes)

        # Paso 2: Crear función main()
        main_type = ir.FunctionType(ir.IntType(32), [])
        main_fn   = ir.Function(self.module, main_type, name="main")
        entry     = main_fn.append_basic_block("entry")
        self._builder = ir.IRBuilder(entry)
        self._current_func_name = "main"

        # Paso 3: Emitir código para cada nodo del programa
        i = 0
        while i < len(program_nodes):
            node = program_nodes[i]
            node_type = list(node.keys())[0]

            if node_type == "WhileLoop":
                if i + 1 < len(program_nodes) and "Block" in program_nodes[i + 1]:
                    node["WhileLoop"]["block"] = program_nodes[i + 1]["Block"]
                    i += 2
                    self._emit_node(node)
                    continue
            if node_type == "SwitchStatement":
                if i + 1 < len(program_nodes) and "block" in program_nodes[i + 1]:
                    node["SwitchStatement"]["cases"] = program_nodes[i + 1].get("cases", [])
                    i += 2
                    self._emit_node(node)
                    continue

            self._emit_node(node)
            i += 1

        # Retornar 0 desde main si no hubo return explícito
        if not self._builder.block.is_terminated:
            self._builder.ret(ir.Constant(ir.IntType(32), 0))

        return str(self.module)

    def _predeclare_functions(self, program_nodes: list):
        """
        Primera pasada: declara todas las funciones en el módulo LLVM
        antes de emitir el cuerpo de ninguna.
        Mismo efecto que handle_Function en interpre.py que registra
        las funciones en la tabla de símbolos.
        """
        for node in program_nodes:
            node_type = list(node.keys())[0]
            if node_type == "Function":
                fn_node = node["Function"]
                self._declare_function_ir(fn_node)

    def _declare_function_ir(self, fn_node: dict):
        """Declara una función Tesseract en LLVM IR (sin emitir el cuerpo todavía)."""
        tess_fn = self.ctx.get_function(fn_node["name"])
        if tess_fn is None:
            return  # no fue analizada (no debería pasar)

        # Construir la firma LLVM
        param_types = [self.types.llvm_type(pt) for pt in tess_fn.params.values()]
        ret_llvm    = self.types.llvm_type(tess_fn.return_type)
        fn_type     = ir.FunctionType(ret_llvm, param_types)

        ir_fn = ir.Function(self.module, fn_type, name=tess_fn.name)
        # Nombrar los parámetros
        for ir_param, pname in zip(ir_fn.args, tess_fn.params.keys()):
            ir_param.name = pname

        self._ir_funcs[tess_fn.name] = ir_fn

    # ── despacho de nodos — mismo patrón que execute_node en interpre.py ─────

    def _emit_node(self, node: dict):
        if not node:
            return
        node_type = list(node.keys())[0]
        emitter = getattr(self, f"_emit_{node_type}", self._emit_unknown)
        return emitter(node[node_type])

    def _emit_block(self, block: List[dict]):
        for stmt in block:
            if self._builder.block.is_terminated:
                break
            self._emit_node(stmt)

    # ── emisores por nodo ─────────────────────────────────────────────────────

    def _emit_VariableDeclaration(self, node: dict):
        name       = node["name"]
        value_node = node.get("value", {})
        tess_sym   = self.ctx.symbol_table.lookup(name)
        ttype      = tess_sym.ttype if tess_sym else TessType.DYNAMIC
        llvm_type  = self.types.llvm_type(ttype)

        alloca = self._alloca(name, llvm_type)
        self._declare_ir_var(name, alloca)

        # Emitir el valor inicial y almacenarlo
        init_val = self._emit_value_node(value_node, ttype)
        if init_val is not None:
            self._builder.store(init_val, alloca)

    def _emit_VariableAsignement(self, node: dict):
        name       = node["name"]
        value_node = node.get("value", {})
        alloca     = self._lookup_ir_var(name)

        if alloca is None:
            # Declaración implícita
            ttype     = TessType.DYNAMIC
            llvm_type = self.types.llvm_type(ttype)
            alloca    = self._alloca(name, llvm_type)
            self._declare_ir_var(name, alloca)

        tess_sym = self.ctx.symbol_table.lookup(name)
        ttype    = tess_sym.ttype if tess_sym else TessType.DYNAMIC
        val      = self._emit_value_node(value_node, ttype)
        if val is not None:
            self._builder.store(val, alloca)

    def _emit_ConstantDeclaration(self, node: dict):
        # Misma lógica que VariableDeclaration pero marcado is_const
        self._emit_VariableDeclaration(node)

    def _emit_Function(self, fn_node: dict):
        """
        Emite el cuerpo de una función Tesseract.
        La declaración ya fue hecha en _predeclare_functions.
        """
        name    = fn_node["name"]
        tess_fn = self.ctx.get_function(name)
        ir_fn   = self._ir_funcs.get(name)
        if ir_fn is None or tess_fn is None:
            return

        # Guardar estado del builder actual
        old_builder      = self._builder
        old_func_name    = self._current_func_name
        old_scope        = self._scope_stack[:]
        old_break        = self._break_target
        old_ret_alloca   = self._return_alloca
        old_ret_block    = self._return_block

        # Nuevo scope para la función
        self._push_scope()
        self._current_func_name = name
        self._break_target = None

        # Entry block
        entry_block = ir_fn.append_basic_block("entry")
        self._builder = ir.IRBuilder(entry_block)

        # Bloque de retorno (epilogo)
        ret_block = ir_fn.append_basic_block("func_return")
        self._return_block = ret_block

        # Alloca para el valor de retorno (si no es void)
        if tess_fn.return_type != TessType.VOID:
            ret_type = self.types.llvm_type(tess_fn.return_type)
            self._return_alloca = self._alloca("retval", ret_type)
        else:
            self._return_alloca = None

        # Materializar parámetros: alloca + store para cada param
        for ir_param, (pname, ptype) in zip(ir_fn.args, tess_fn.params.items()):
            llvm_type = self.types.llvm_type(ptype)
            alloca    = self._alloca(pname, llvm_type)
            self._builder.store(ir_param, alloca)
            self._declare_ir_var(pname, alloca)

        # Emitir el cuerpo
        self._emit_block(tess_fn.body)

        # Saltar al bloque de retorno si el bloque actual no terminó
        if not self._builder.block.is_terminated:
            self._builder.branch(ret_block)

        # Emitir el bloque de retorno
        self._builder.position_at_start(ret_block)
        if tess_fn.return_type == TessType.VOID or self._return_alloca is None:
            self._builder.ret_void()
        else:
            ret_val = self._builder.load(self._return_alloca, "ret_load")
            self._builder.ret(ret_val)

        # Restaurar estado
        self._pop_scope()
        self._builder           = old_builder
        self._current_func_name = old_func_name
        self._scope_stack       = old_scope
        self._break_target      = old_break
        self._return_alloca     = old_ret_alloca
        self._return_block      = old_ret_block

    def _emit_FunctionCall(self, node: dict):
        """Llamada a función Tesseract (standalone, no como valor)."""
        fname      = node["function"]
        params_raw = node.get("paramenters", {})
        args       = self._emit_call_args(params_raw)
        ir_fn      = self._ir_funcs.get(fname)
        if ir_fn:
            self._builder.call(ir_fn, args)

    def _emit_CallExpression(self, node: dict):
        """
        Builtins: print, read, Return, Break y llamadas a módulo.
        Misma cobertura que handle_CallExpression en interpre.py.
        """
        fname = node.get("function", "")

        # ── Break ────────────────────────────────────────────────────────────
        if fname == "Break":
            if self._break_target:
                self._builder.branch(self._break_target)
            return

        # ── Return ───────────────────────────────────────────────────────────
        if fname == "Return":
            ret_node = node.get("value") or node.get("arguments") or {}
            ret_val  = None
            if "value" in ret_node:
                raw = ret_node["value"]
                if isinstance(raw, str):
                    expr    = self.ctx.parse_expression(raw)
                    ret_val = self._emit_expr(expr)
                elif isinstance(raw, (int, float, bool)):
                    ret_val = self._python_literal_to_ir(raw)

            if self._return_alloca is not None and ret_val is not None:
                self._builder.store(ret_val, self._return_alloca)
            if self._return_block:
                self._builder.branch(self._return_block)
            return

        # ── Llamada a módulo: mod.func(...) ───────────────────────────────────
        if isinstance(fname, str) and '.' in fname:
            self._emit_module_call_from_node(node)
            return

        # ── print ────────────────────────────────────────────────────────────
        if fname == "print":
            self._emit_print(node)
            return

        # ── read ─────────────────────────────────────────────────────────────
        if fname == "read":
            self._emit_read(node)
            return

        # ── función Tesseract declarada por el usuario ────────────────────────
        ir_fn = self._ir_funcs.get(fname)
        if ir_fn:
            args = self._emit_call_args(node.get("arguments", {}))
            self._builder.call(ir_fn, args)

    def _emit_LibraryCall(self, node: dict):
        """Los módulos no generan IR directamente — ya están registrados en ctx."""
        pass

    def _emit_if_Condition(self, node: dict):
        """
        if / elseif / else.
        Genera bloques básicos LLVM y conecta con br condicionales.
        """
        fn        = self._builder.function
        then_bb   = fn.append_basic_block("if_then")
        merge_bb  = fn.append_basic_block("if_merge")

        # Determinar si hay else o elseif
        has_else   = "else"   in node
        has_elseif = "elseIf" in node
        else_bb    = fn.append_basic_block("if_else") if (has_else or has_elseif) else merge_bb

        # Emitir condición
        cond_val = self._emit_condition(node["condition"])
        self._builder.cbranch(cond_val, then_bb, else_bb)

        # Bloque then
        self._builder.position_at_start(then_bb)
        self._push_scope()
        self._emit_block(node.get("block", []))
        self._pop_scope()
        if not self._builder.block.is_terminated:
            self._builder.branch(merge_bb)

        # Bloque else / elseif
        if has_else or has_elseif:
            self._builder.position_at_start(else_bb)
            if has_elseif:
                self._emit_elseif_chain(node["elseIf"], merge_bb)
            elif has_else:
                self._push_scope()
                self._emit_block(node["else"].get("block", []))
                self._pop_scope()
                if not self._builder.block.is_terminated:
                    self._builder.branch(merge_bb)

        self._builder.position_at_start(merge_bb)

    def _emit_elseif_chain(self, node: dict, merge_bb: ir.Block):
        fn      = self._builder.function
        then_bb = fn.append_basic_block("elseif_then")
        has_else   = "else"   in node
        has_elseif = "elseIf" in node
        next_bb = fn.append_basic_block("elseif_next") if (has_else or has_elseif) else merge_bb

        cond_val = self._emit_condition(node.get("condition") or node.get("value", "false"))
        self._builder.cbranch(cond_val, then_bb, next_bb)

        self._builder.position_at_start(then_bb)
        self._push_scope()
        self._emit_block(node.get("block", []))
        self._pop_scope()
        if not self._builder.block.is_terminated:
            self._builder.branch(merge_bb)

        if has_else or has_elseif:
            self._builder.position_at_start(next_bb)
            if has_elseif:
                self._emit_elseif_chain(node["elseIf"], merge_bb)
            else:
                self._push_scope()
                self._emit_block(node["else"].get("block", []))
                self._pop_scope()
                if not self._builder.block.is_terminated:
                    self._builder.branch(merge_bb)

    def _emit_ForLoop(self, node: dict):
        """
        for var in start..end
        Genera un loop LLVM clásico con bloques: preheader, header, body, exit.
        Misma lógica que handle_ForLoop en interpre.py.
        """
        var_name    = node["variable"]
        iterator    = node["iterator"]["value"]   # "1..10" o "start..end"
        fn          = self._builder.function

        # Parsear los límites del rango
        start_ir, end_ir = self._emit_range_bounds(iterator)

        # Alloca para la variable iteradora
        alloca = self._alloca(var_name, ir.IntType(64))
        self._builder.store(start_ir, alloca)

        # Bloques del loop
        header_bb = fn.append_basic_block("for_header")
        body_bb   = fn.append_basic_block("for_body")
        exit_bb   = fn.append_basic_block("for_exit")

        old_break       = self._break_target
        self._break_target = exit_bb

        self._builder.branch(header_bb)

        # Header: condición i <= end
        self._builder.position_at_start(header_bb)
        cur_val = self._builder.load(alloca, "for_cur")
        cond    = self._builder.icmp_signed("<=", cur_val, end_ir, "for_cond")
        self._builder.cbranch(cond, body_bb, exit_bb)

        # Body
        self._builder.position_at_start(body_bb)
        self._push_scope()
        self._declare_ir_var(var_name, alloca)
        self._emit_block(node.get("block", []))
        self._pop_scope()

        if not self._builder.block.is_terminated:
            # Incremento: i++
            cur_val2  = self._builder.load(alloca, "for_inc_cur")
            next_val  = self._builder.add(cur_val2, ir.Constant(ir.IntType(64), 1), "for_inc")
            self._builder.store(next_val, alloca)
            self._builder.branch(header_bb)

        self._break_target = old_break
        self._builder.position_at_start(exit_bb)

    def _emit_WhileLoop(self, node: dict):
        fn          = self._builder.function
        condition   = node["condition"]
        header_bb   = fn.append_basic_block("while_header")
        body_bb     = fn.append_basic_block("while_body")
        exit_bb     = fn.append_basic_block("while_exit")

        old_break          = self._break_target
        self._break_target = exit_bb

        self._builder.branch(header_bb)

        # Header: evaluar condición
        self._builder.position_at_start(header_bb)
        cond_val = self._emit_condition(condition)
        self._builder.cbranch(cond_val, body_bb, exit_bb)

        # Body
        self._builder.position_at_start(body_bb)
        self._push_scope()
        self._emit_block(node.get("block", []))
        self._pop_scope()
        if not self._builder.block.is_terminated:
            self._builder.branch(header_bb)

        self._break_target = old_break
        self._builder.position_at_start(exit_bb)

    def _emit_PerformWhileLoop(self, node: dict):
        """do-while: ejecuta el bloque al menos una vez."""
        fn        = self._builder.function
        condition = node["value"]
        body_bb   = fn.append_basic_block("dowhile_body")
        check_bb  = fn.append_basic_block("dowhile_check")
        exit_bb   = fn.append_basic_block("dowhile_exit")

        old_break          = self._break_target
        self._break_target = exit_bb

        self._builder.branch(body_bb)

        # Body (siempre se ejecuta al menos una vez)
        self._builder.position_at_start(body_bb)
        self._push_scope()
        self._emit_block(node.get("block", []))
        self._pop_scope()
        if not self._builder.block.is_terminated:
            self._builder.branch(check_bb)

        # Check: ¿repetir?
        self._builder.position_at_start(check_bb)
        cond_val = self._emit_condition(condition)
        self._builder.cbranch(cond_val, body_bb, exit_bb)

        self._break_target = old_break
        self._builder.position_at_start(exit_bb)

    def _emit_SwitchStatement(self, node: dict):
        """Switch Tesseract → switch instruction de LLVM."""
        var_name = node["value"]
        alloca   = self._lookup_ir_var(var_name)
        fn       = self._builder.function

        switch_val: Any
        if alloca:
            switch_val = self._builder.load(alloca, "switch_val")
        else:
            switch_val = ir.Constant(ir.IntType(64), 0)

        default_bb = fn.append_basic_block("switch_default")
        merge_bb   = fn.append_basic_block("switch_merge")

        sw = self._builder.switch(switch_val, default_bb)

        case_blocks = []
        for case in node.get("cases", []):
            case_val = case.get("case")
            bb = fn.append_basic_block(f"switch_case_{case_val}")
            # Solo soportamos casos int como switch nativos
            try:
                sw.add_case(ir.Constant(ir.IntType(64), int(case_val)), bb)
            except (TypeError, ValueError):
                pass  # casos string van al default dinámico
            case_blocks.append((bb, case))

        for bb, case in case_blocks:
            self._builder.position_at_start(bb)
            self._push_scope()
            self._emit_block(case.get("block", []))
            self._pop_scope()
            if not self._builder.block.is_terminated:
                self._builder.branch(merge_bb)

        # Default
        self._builder.position_at_start(default_bb)
        default = node.get("defaultCase")
        if default:
            self._push_scope()
            self._emit_block(default.get("block", []))
            self._pop_scope()
        if not self._builder.block.is_terminated:
            self._builder.branch(merge_bb)

        self._builder.position_at_start(merge_bb)

    def _emit_PostIncrementStatement(self, node: dict):
        self._emit_incr_decr(node["value"], +1)

    def _emit_PostDecrementStatement(self, node: dict):
        self._emit_incr_decr(node["value"], -1)

    def _emit_PreIncrementStatement(self, node: dict):
        self._emit_incr_decr(node["value"], +1)

    def _emit_PreDecrementStatement(self, node: dict):
        self._emit_incr_decr(node["value"], -1)

    def _emit_ParameterAsignement(self, node: dict):
        """Re-asignación de parámetro dentro de función."""
        self._emit_VariableAsignement(node)

    def _emit_unknown(self, node_content):
        pass  # Nodo no implementado — ignorar silenciosamente

    # ── emisores de expresiones — recorren ExprNode ──────────────────────────

    def _emit_expr(self, node: ExprNode) -> Any:
        """
        Recorre un árbol ExprNode y emite instrucciones IR.
        Retorna el ir.Value resultado.
        """
        if isinstance(node, LiteralNode):
            return self._emit_literal(node)

        if isinstance(node, VarNode):
            return self._emit_var_load(node.name)

        if isinstance(node, BinOpNode):
            return self._emit_binop(node)

        if isinstance(node, LogicalNode):
            return self._emit_logical(node)

        if isinstance(node, UnaryNode):
            return self._emit_unary(node)

        if isinstance(node, ConcatNode):
            return self._emit_concat(node)

        if isinstance(node, FuncCallNode):
            return self._emit_func_call_expr(node)

        if isinstance(node, ModCallNode):
            return self._emit_mod_call_expr(node)

        if isinstance(node, ModVarNode):
            return self._emit_mod_var(node)

        if isinstance(node, ArrayAccessNode):
            return self._emit_array_access(node)

        # Fallback: null
        return self._builder.call(self.runtime.get("tess_make_null"), [])

    def _emit_literal(self, node: LiteralNode) -> Any:
        if node.ttype == TessType.INT:
            return ir.Constant(ir.IntType(64), int(node.value))
        if node.ttype == TessType.FLOAT:
            return ir.Constant(ir.DoubleType(), float(node.value))
        if node.ttype == TessType.BOOL:
            return ir.Constant(ir.IntType(1), 1 if node.value else 0)
        if node.ttype == TessType.STRING:
            s = str(node.value) if node.value is not None else ""
            str_ptr = self._str_const(s)
            return self._builder.call(self.runtime.get("tess_make_string"), [str_ptr])
        if node.ttype == TessType.NULL:
            return self._builder.call(self.runtime.get("tess_make_null"), [])
        if node.ttype == TessType.DYNAMIC:
            # Expresión dinámica no parseada — tratar como null
            return self._builder.call(self.runtime.get("tess_make_null"), [])
        return self._builder.call(self.runtime.get("tess_make_null"), [])

    def _emit_var_load(self, name: str) -> Any:
        alloca = self._lookup_ir_var(name)
        if alloca:
            return self._builder.load(alloca, name)
        # Variable no encontrada en IR — retornar null dinámico
        return self._builder.call(self.runtime.get("tess_make_null"), [])

    def _emit_binop(self, node: BinOpNode) -> Any:
        left  = self._emit_expr(node.left)
        right = self._emit_expr(node.right)

        # Inferir tipos de los operandos para decidir el camino estático o dinámico
        lt = self._ir_type_of(left)
        rt = self._ir_type_of(right)

        # ── Camino estático: ambos int ───────────────────────────────────────
        if lt == ir.IntType(64) and rt == ir.IntType(64):
            return self._emit_int_binop(node.op, left, right)

        # ── Camino estático: alguno float ────────────────────────────────────
        if lt in (ir.DoubleType(), ir.IntType(64)) and rt in (ir.DoubleType(), ir.IntType(64)):
            l = self._builder.sitofp(left, ir.DoubleType()) if lt == ir.IntType(64) else left
            r = self._builder.sitofp(right, ir.DoubleType()) if rt == ir.IntType(64) else right
            return self._emit_float_binop(node.op, l, r)

        # ── Camino dinámico: via runtime C ───────────────────────────────────
        lv = self._to_tess_value(left)
        rv = self._to_tess_value(right)
        op_map = {
            '+': 'tess_add', '-': 'tess_sub', '*': 'tess_mul',
            '/': 'tess_div', '%': 'tess_mod',
            '==': 'tess_eq', '!=': 'tess_neq',
            '<':  'tess_lt', '>':  'tess_gt',
            '<=': 'tess_lte', '>=': 'tess_gte',
        }
        rt_fn = op_map.get(node.op, 'tess_add')
        return self._builder.call(self.runtime.get(rt_fn), [lv, rv])

    def _emit_int_binop(self, op: str, l: Any, r: Any) -> Any:
        ops = {
            '+': lambda: self._builder.add(l, r, "iadd"),
            '-': lambda: self._builder.sub(l, r, "isub"),
            '*': lambda: self._builder.mul(l, r, "imul"),
            '/': lambda: self._builder.sdiv(l, r, "idiv"),
            '%': lambda: self._builder.srem(l, r, "imod"),
            '==': lambda: self._builder.icmp_signed('==', l, r, "ieq"),
            '!=': lambda: self._builder.icmp_signed('!=', l, r, "ineq"),
            '<':  lambda: self._builder.icmp_signed('<',  l, r, "ilt"),
            '>':  lambda: self._builder.icmp_signed('>',  l, r, "igt"),
            '<=': lambda: self._builder.icmp_signed('<=', l, r, "ilte"),
            '>=': lambda: self._builder.icmp_signed('>=', l, r, "igte"),
        }
        return ops[op]() if op in ops else ir.Constant(ir.IntType(64), 0)

    def _emit_float_binop(self, op: str, l: Any, r: Any) -> Any:
        ops = {
            '+': lambda: self._builder.fadd(l, r, "fadd"),
            '-': lambda: self._builder.fsub(l, r, "fsub"),
            '*': lambda: self._builder.fmul(l, r, "fmul"),
            '/': lambda: self._builder.fdiv(l, r, "fdiv"),
            '==': lambda: self._builder.fcmp_ordered('==', l, r, "feq"),
            '!=': lambda: self._builder.fcmp_ordered('!=', l, r, "fneq"),
            '<':  lambda: self._builder.fcmp_ordered('<',  l, r, "flt"),
            '>':  lambda: self._builder.fcmp_ordered('>',  l, r, "fgt"),
            '<=': lambda: self._builder.fcmp_ordered('<=', l, r, "flte"),
            '>=': lambda: self._builder.fcmp_ordered('>=', l, r, "fgte"),
        }
        return ops[op]() if op in ops else ir.Constant(ir.DoubleType(), 0.0)

    def _emit_logical(self, node: LogicalNode) -> Any:
        left  = self._emit_expr(node.left)
        right = self._emit_expr(node.right)
        # Si son TessValue, extraer truthiness
        lt = self._ir_type_of(left)
        if lt != ir.IntType(1):
            left  = self._builder.call(self.runtime.get("tess_value_truthy"), [self._to_tess_value(left)])
            right = self._builder.call(self.runtime.get("tess_value_truthy"), [self._to_tess_value(right)])
        if node.op == '&&':
            return self._builder.and_(left, right, "and")
        return self._builder.or_(left, right, "or")

    def _emit_unary(self, node: UnaryNode) -> Any:
        val = self._emit_expr(node.operand)
        if node.op == '-':
            vt = self._ir_type_of(val)
            if vt == ir.IntType(64):
                return self._builder.neg(val, "ineg")
            if vt == ir.DoubleType():
                return self._builder.fneg(val, "fneg")
            return self._builder.call(self.runtime.get("tess_neg"), [self._to_tess_value(val)])
        if node.op == '!':
            vt = self._ir_type_of(val)
            if vt == ir.IntType(1):
                return self._builder.not_(val, "lnot")
            tv = self._to_tess_value(val)
            return self._builder.call(self.runtime.get("tess_not"), [tv])
        return val

    def _emit_concat(self, node: ConcatNode) -> Any:
        """Concatenación con punto: emite calls a tess_concat."""
        tv = self.types.tess_value_ptr_t
        acc = self._builder.call(self.runtime.get("tess_make_string"),
                                 [self._str_const("")])
        for part in node.parts:
            val  = self._emit_expr(part)
            part_tv = self._to_tess_value(val)
            acc = self._builder.call(self.runtime.get("tess_concat"), [acc, part_tv])
        return acc

    def _emit_func_call_expr(self, node: FuncCallNode) -> Any:
        ir_fn = self._ir_funcs.get(node.name)
        if ir_fn:
            args = [self._emit_expr(a) for a in node.args]
            return self._builder.call(ir_fn, args, "func_ret")
        return self._builder.call(self.runtime.get("tess_make_null"), [])

    def _emit_mod_call_expr(self, node: ModCallNode) -> Any:
        """
        Llamada a módulo: mod.func(args).
        Como los módulos nativos son librerías C, emitimos una llamada
        externa declarada dinámicamente.
        """
        mangled = f"_tess_mod_{node.module}_{node.func}"
        fn = self.module.globals.get(mangled)
        if fn is None:
            tv  = self.types.tess_value_ptr_t
            arg_types = [tv] * len(node.args)
            fn_type = ir.FunctionType(tv, arg_types)
            fn = ir.Function(self.module, fn_type, name=mangled)
        args = [self._to_tess_value(self._emit_expr(a)) for a in node.args]
        return self._builder.call(fn, args, "mod_ret")

    def _emit_mod_var(self, node: ModVarNode) -> Any:
        """Acceso a variable de módulo: mod.VAR."""
        mangled = f"_tess_modvar_{node.module}_{node.var}"
        gvar = self.module.globals.get(mangled)
        if gvar is None:
            gvar = ir.GlobalVariable(self.module, self.types.tess_value_ptr_t, name=mangled)
            gvar.linkage = 'external'
        return self._builder.load(gvar, "mod_var")

    def _emit_array_access(self, node: ArrayAccessNode) -> Any:
        alloca = self._lookup_ir_var(node.array)
        if alloca is None:
            return self._builder.call(self.runtime.get("tess_make_null"), [])
        arr = self._builder.load(alloca, "arr")
        arr_tv = self._to_tess_value(arr)
        # Solo primer índice (acceso simple)
        idx = self._emit_expr(node.indices[0])
        idx_i64 = self._coerce_to_i64(idx)
        return self._builder.call(self.runtime.get("tess_array_get"), [arr_tv, idx_i64])

    # ── helpers de emisión ───────────────────────────────────────────────────

    def _emit_condition(self, condition_str: str) -> Any:
        """
        Emite código IR para una condición booleana (string del AST).
        Normaliza && → and, || → or como lo hace evaluate_expression.
        """
        condition_str = condition_str.replace("&&", " && ").replace("||", " || ")
        expr   = self.ctx.parse_expression(condition_str)
        result = self._emit_expr(expr)
        # Asegurar que el resultado es i1
        rt = self._ir_type_of(result)
        if rt == ir.IntType(1):
            return result
        if rt == ir.IntType(64):
            return self._builder.icmp_signed('!=', result, ir.Constant(ir.IntType(64), 0), "to_bool")
        if rt == ir.DoubleType():
            return self._builder.fcmp_ordered('!=', result, ir.Constant(ir.DoubleType(), 0.0), "to_bool")
        # TessValue → tess_value_truthy
        tv = self._to_tess_value(result)
        return self._builder.call(self.runtime.get("tess_value_truthy"), [tv])

    def _emit_value_node(self, value_node: dict, hint_type: TessType) -> Optional[Any]:
        """
        Emite IR para un nodo value del AST.
        Equivale a la lógica de resolve_expression + handle_VariableDeclaration.
        """
        ast_type  = value_node.get("type", "")
        raw_value = value_node.get("value")

        if ast_type == "NULL" or raw_value == "null":
            return self._builder.call(self.runtime.get("tess_make_null"), [])

        # Valor literal Python directo
        if isinstance(raw_value, bool):
            return ir.Constant(ir.IntType(1), 1 if raw_value else 0)
        if isinstance(raw_value, int):
            return ir.Constant(ir.IntType(64), raw_value)
        if isinstance(raw_value, float):
            return ir.Constant(ir.DoubleType(), raw_value)

        if isinstance(raw_value, str):
            # String literal con comillas
            if raw_value.startswith('"') and raw_value.endswith('"'):
                s = raw_value[1:-1]
                ptr = self._str_const(s)
                return self._builder.call(self.runtime.get("tess_make_string"), [ptr])

            # Expresión / operación
            expr = self.ctx.parse_expression(raw_value)
            return self._emit_expr(expr)

        if isinstance(raw_value, list):
            # Array literal
            return self._emit_array_literal(raw_value)

        if isinstance(raw_value, dict):
            # Dict literal
            return self._emit_dict_literal(raw_value)

        return self._builder.call(self.runtime.get("tess_make_null"), [])

    def _emit_print(self, node: dict):
        """
        Emite una llamada a la función print del runtime.
        Detecta el tipo del argumento y llama a la versión correcta.
        Mismo comportamiento que handle_CallExpression para 'print'.
        """
        args_node  = node.get("arguments", {})
        param_type = node.get("paramType", "")
        raw_arg    = args_node.get("value") if isinstance(args_node, dict) else args_node

        if raw_arg is None:
            self._builder.call(self.runtime.get("tess_print_null"), [])
            return

        val = None

        # String literal
        if isinstance(raw_arg, str) and raw_arg.startswith('"') and raw_arg.endswith('"'):
            ptr = self._str_const(raw_arg[1:-1])
            self._builder.call(self.runtime.get("tess_print_string"), [ptr])
            return

        # Expresión
        if isinstance(raw_arg, str):
            expr = self.ctx.parse_expression(raw_arg)
            val  = self._emit_expr(expr)
        elif isinstance(raw_arg, (int, float, bool)):
            val = self._python_literal_to_ir(raw_arg)

        if val is None:
            self._builder.call(self.runtime.get("tess_print_null"), [])
            return

        # Elegir función de print según tipo IR
        vt = self._ir_type_of(val)
        if vt == ir.IntType(64):
            self._builder.call(self.runtime.get("tess_print_int"), [val])
        elif vt == ir.DoubleType():
            self._builder.call(self.runtime.get("tess_print_float"), [val])
        elif vt == ir.IntType(1):
            self._builder.call(self.runtime.get("tess_print_bool"), [val])
        elif vt == ir.IntType(8).as_pointer():
            self._builder.call(self.runtime.get("tess_print_string"), [val])
        else:
            tv = self._to_tess_value(val)
            self._builder.call(self.runtime.get("tess_print_value"), [tv])

    def _emit_read(self, node: dict):
        """Lee input y asigna a la variable indicada."""
        args_node   = node.get("arguments", {})
        param_type  = node.get("paramType", "string")
        var_name    = args_node.get("value") if isinstance(args_node, dict) else str(args_node)

        alloca = self._lookup_ir_var(var_name)
        if alloca is None:
            return

        if param_type == 'Int':
            val = self._builder.call(self.runtime.get("tess_read_int"), [])
        elif param_type == 'Float':
            val = self._builder.call(self.runtime.get("tess_read_float"), [])
        else:
            val = self._builder.call(self.runtime.get("tess_read_string"), [])

        self._builder.store(val, alloca)

    def _emit_module_call_from_node(self, node: dict):
        """Llamada mod.func() desde un CallExpression."""
        fname      = node.get("function", "")
        parts      = fname.strip().rstrip('()').split('.', 1)
        if len(parts) != 2:
            return
        mod_name, func_name = parts
        args_node  = node.get("arguments", {})
        raw_args   = args_node.get("value", "") if isinstance(args_node, dict) else ""

        # Construir lista de argumentos
        parsed_args = []
        for part in raw_args.split(','):
            part = part.strip()
            if not part:
                continue
            if ':' in part:
                _, v = part.split(':', 1)
                part = v.strip()
            expr = self.ctx.parse_expression(part)
            parsed_args.append(self._to_tess_value(self._emit_expr(expr)))

        mangled = f"_tess_mod_{mod_name}_{func_name}"
        fn = self.module.globals.get(mangled)
        if fn is None:
            tv = self.types.tess_value_ptr_t
            fn_type = ir.FunctionType(tv, [tv] * len(parsed_args))
            fn = ir.Function(self.module, fn_type, name=mangled)
        self._builder.call(fn, parsed_args)

    def _emit_incr_decr(self, var_name: str, delta: int):
        alloca = self._lookup_ir_var(var_name)
        if alloca is None:
            return
        sym = self.ctx.symbol_table.lookup(var_name)
        if sym and sym.ttype == TessType.INT:
            cur = self._builder.load(alloca, "incr_cur")
            new = self._builder.add(cur, ir.Constant(ir.IntType(64), delta), "incr_new")
            self._builder.store(new, alloca)
        elif sym and sym.ttype == TessType.FLOAT:
            cur = self._builder.load(alloca, "incr_cur")
            new = self._builder.fadd(cur, ir.Constant(ir.DoubleType(), float(delta)), "incr_new")
            self._builder.store(new, alloca)
        else:
            # Dinámico
            cur = self._builder.load(alloca, "incr_cur")
            tv  = self._to_tess_value(cur)
            rt_fn = "tess_inc" if delta > 0 else "tess_dec"
            new = self._builder.call(self.runtime.get(rt_fn), [tv])
            self._builder.store(new, alloca)

    def _emit_range_bounds(self, iterator_str: str) -> Tuple[Any, Any]:
        """
        Parsea "start..end" y emite los valores IR para los límites.
        Misma lógica que _validate_and_parse_range en interpre.py.
        """
        if ".." not in iterator_str:
            return ir.Constant(ir.IntType(64), 0), ir.Constant(ir.IntType(64), 0)
        parts = iterator_str.split("..")
        start_expr = self.ctx.parse_expression(parts[0].strip())
        end_expr   = self.ctx.parse_expression(parts[1].strip())
        start = self._emit_expr(start_expr)
        end   = self._emit_expr(end_expr)
        start = self._coerce_to_i64(start)
        end   = self._coerce_to_i64(end)
        return start, end

    def _emit_array_literal(self, items: list) -> Any:
        """Crea un TessArray desde un literal de array."""
        arr = self._builder.call(self.runtime.get("tess_array_new"), [])
        for item in items:
            val = self._python_literal_to_ir(item)
            tv  = self._to_tess_value(val)
            self._builder.call(self.runtime.get("tess_array_push"), [arr, tv])
        return arr

    def _emit_dict_literal(self, d: dict) -> Any:
        """Crea un TessDict desde un literal de diccionario."""
        dct = self._builder.call(self.runtime.get("tess_dict_new"), [])
        for key, val in d.items():
            key_ptr = self._str_const(str(key))
            val_ir  = self._python_literal_to_ir(val)
            tv      = self._to_tess_value(val_ir)
            self._builder.call(self.runtime.get("tess_dict_set"), [dct, key_ptr, tv])
        return dct

    def _emit_call_args(self, params_node: dict) -> List[Any]:
        """
        Parsea y emite los argumentos de una llamada.
        Misma lógica que _parse_call_parameters en interpre.py.
        """
        args = []
        if not params_node:
            return args
        raw = params_node.get("value", "") if isinstance(params_node, dict) else str(params_node)
        for part in raw.split(','):
            part = part.strip()
            if not part:
                continue
            if ':' in part and not (part.startswith('"') or part.startswith("'")):
                _, v = part.split(':', 1)
                part = v.strip()
            expr = self.ctx.parse_expression(part)
            args.append(self._emit_expr(expr))
        return args

    # ── utilidades de tipo IR ────────────────────────────────────────────────

    def _ir_type_of(self, val: Any) -> Optional[ir.Type]:
        """Retorna el tipo IR de un valor."""
        if hasattr(val, 'type'):
            return val.type
        return None

    def _to_tess_value(self, val: Any) -> Any:
        """Convierte un valor IR nativo a TessValue* via el runtime."""
        vt = self._ir_type_of(val)
        if vt is None:
            return self._builder.call(self.runtime.get("tess_make_null"), [])
        if vt == ir.IntType(64):
            return self._builder.call(self.runtime.get("tess_make_int"), [val])
        if vt == ir.DoubleType():
            return self._builder.call(self.runtime.get("tess_make_float"), [val])
        if vt == ir.IntType(1):
            return self._builder.call(self.runtime.get("tess_make_bool"), [val])
        if vt == ir.IntType(8).as_pointer():
            return self._builder.call(self.runtime.get("tess_make_string"), [val])
        # Ya es TessValue* o algo compatible
        return val

    def _coerce_to_i64(self, val: Any) -> Any:
        """Convierte un valor IR a i64 (para índices, rangos, etc.)."""
        vt = self._ir_type_of(val)
        if vt == ir.IntType(64):
            return val
        if vt == ir.DoubleType():
            return self._builder.fptosi(val, ir.IntType(64), "fptoi")
        if vt == ir.IntType(1):
            return self._builder.zext(val, ir.IntType(64), "btoi")
        # TessValue → extraer como int
        tv = self._to_tess_value(val)
        return self._builder.call(self.runtime.get("tess_to_int"), [tv])

    def _python_literal_to_ir(self, val: Any) -> Any:
        """Convierte un literal Python a un valor IR."""
        if isinstance(val, bool):
            return ir.Constant(ir.IntType(1), 1 if val else 0)
        if isinstance(val, int):
            return ir.Constant(ir.IntType(64), val)
        if isinstance(val, float):
            return ir.Constant(ir.DoubleType(), val)
        if isinstance(val, str):
            ptr = self._str_const(val)
            return self._builder.call(self.runtime.get("tess_make_string"), [ptr])
        return self._builder.call(self.runtime.get("tess_make_null"), [])


# =============================================================================
# Driver — pipeline completo
# =============================================================================

def compile_ast(ast_json: dict,
                module_name: str = "tesseract_module",
                debug: bool = False) -> str:
    """
    Pipeline completo:
      1. Analizar el AST con tessruntime (CompileContext)
      2. Emitir LLVM IR con CodeGen
      3. Retornar el IR como string
    """
    ctx = analyze_ast(ast_json, debug=debug)
    gen = CodeGen(ctx, module_name=module_name)
    return gen.generate(ast_json)


def compile_to_file(ast_path:    str,
                    output_path: str,
                    module_name: str = "tesseract_module",
                    debug:       bool = False):
    """
    Lee un JSON AST, genera LLVM IR y lo escribe en output_path (.ll).
    """
    with open(ast_path, 'r', encoding='utf-8') as f:
        ast_json = json.load(f)

    ir_str = compile_ast(ast_json, module_name=module_name, debug=debug)

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(ir_str)

    print(f"[tesscodegen] IR escrito en: {output_path}")
    return output_path


def compile_to_binary(ast_path:    str,
                      output_path: str,
                      runtime_lib: str = "tess_runtime.c",
                      debug:       bool = False):
    """
    Pipeline completo hasta binario nativo:
      1. JSON AST → LLVM IR (.ll)
      2. .ll → objeto (.o)
      3. .o + runtime C → binario nativo

    Requiere: llc, clang o gcc en el PATH.
    runtime_lib: ruta al archivo tess_runtime.c
    """
    import subprocess
    import tempfile

    # Paso 1: generar IR
    ll_path = output_path + ".ll"
    compile_to_file(ast_path, ll_path, debug=debug)

    # Paso 2: IR → objeto
    obj_path = output_path + ".o"
    res = subprocess.run(["llc", "-filetype=obj", ll_path, "-o", obj_path],
                         capture_output=True, text=True)
    if res.returncode != 0:
        raise RuntimeError(f"llc falló:\n{res.stderr}")
    print(f"[tesscodegen] Objeto: {obj_path}")

    # Paso 3: linkear con el runtime C
    cmd = ["clang", obj_path, runtime_lib, "-o", output_path, "-lm"]
    res = subprocess.run(cmd, capture_output=True, text=True)
    if res.returncode != 0:
        # Intentar con gcc
        cmd[0] = "gcc"
        res = subprocess.run(cmd, capture_output=True, text=True)
        if res.returncode != 0:
            raise RuntimeError(f"Linkeo falló:\n{res.stderr}")

    print(f"[tesscodegen] Binario nativo: {output_path}")
    return output_path


# =============================================================================
# CLI
# =============================================================================

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Tesseract LLVM IR Code Generator")
    parser.add_argument("ast",     help="Ruta al archivo JSON del AST")
    parser.add_argument("-o",      dest="output", default="output", help="Nombre del archivo de salida")
    parser.add_argument("--ir",    action="store_true", help="Solo generar IR (.ll), no compilar")
    parser.add_argument("--bin",   action="store_true", help="Compilar hasta binario nativo")
    parser.add_argument("--runtime", default="tess_runtime.c", help="Ruta al runtime C")
    parser.add_argument("-d",      dest="debug", action="store_true", help="Modo debug")
    args = parser.parse_args()

    if args.bin:
        compile_to_binary(args.ast, args.output, runtime_lib=args.runtime, debug=args.debug)
    else:
        out = args.output if args.output.endswith(".ll") else args.output + ".ll"
        compile_to_file(args.ast, out, debug=args.debug)
        print("\n--- LLVM IR generado ---")
        with open(out) as f:
            print(f.read())
